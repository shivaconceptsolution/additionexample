from django.shortcuts import render

def index(request):
	return render(request,"formexample/index.html")
def addlogic(request):
	a = request.GET["txtnum1"]
	b = request.GET["txtnum2"]
	c = int(a)+int(b)
	return render(request,"formexample/index.html",{'r':c})