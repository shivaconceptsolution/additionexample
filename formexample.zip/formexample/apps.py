from django.apps import AppConfig


class FormexampleConfig(AppConfig):
    name = 'formexample'
